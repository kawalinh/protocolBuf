package tagcade.rtb.auction.builder;

import tagcade.rtb.auction.model.AdDetail;
import tagcade.rtb.auction.model.AdRequest;
import tagcade.rtb.auction.model.request.BidRequest;

public class BidRequestBuilder implements BidRequestBuilderInterface{

	@Override
	public BidRequest buildBidRequest(AdRequest adRequest, AdDetail adDetail) {
		System.out.println("--------------------------buildBidRequest---------------------------------------");
		return null;
	}

}
