package tagcade.rtb.auction.builder;

import tagcade.rtb.auction.model.AdDetail;
import tagcade.rtb.auction.model.AdRequest;
import tagcade.rtb.auction.model.request.BidRequest;

public interface BidRequestBuilderInterface {

	public BidRequest buildBidRequest(AdRequest adRequest, AdDetail adDetail);
}
