/**
 * 
 */
package tagcade.rtb.auction.common;

import java.util.HashMap;
import java.util.Map;

import models.Person;
import tagcade.rtb.auction.model.AdRequest;

/**
 * @author pc
 * 
 */
public class AdRequestValidator {

	Person person;// add example
	AdRequest adRequest;

	public Map<String, String> validate(Person person) {

		Map<String, String> map = new HashMap<String, String>();
		String key;
		String value;
		if (person.getName() == null) {
			key = "required";
			value = "Name is required";
			map.put(key, value);
		}

		return map;
	}

	public Map<String, String> validateDetail(AdRequest adRequest) {
		this.adRequest = adRequest;
		Map<String, String> map = new HashMap<String, String>();
		String key;
		String value;
		if (person.getName() == null) {
			key = "required";
			value = "Name is required";
			map.put(key, value);
		}

		return map;
	}

	public boolean validate(AdRequest adRequest) {
		this.adRequest = adRequest;
		boolean rs = true;
		if (person.getName() == null) {
			rs = false;
		}

		return rs;
	}

}
