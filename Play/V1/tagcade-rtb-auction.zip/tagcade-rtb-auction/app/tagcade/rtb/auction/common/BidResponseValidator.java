package tagcade.rtb.auction.common;

public class BidResponseValidator {


}
