/**
 * 
 */
package tagcade.rtb.auction.common;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * @author pc
 * 
 */
public class DSPGroupConfig {

	public DSPGroupConfig() {
		super();
	}

	public Set<String> getConfig(String key) {
		Map<String, Set<String>> map = generateDefaultData();
		Set<String> data = map.get(key);
		return data;
	}

	/**
	 * 1-1: 1-value-1 1-1: 1-value-2 1-1: 1-value-3
	 * 
	 * 2-2: 2-value-1 2-2: 2-value-2 2-2: 2-value-3
	 * 
	 * 3-3: 3-value-1 3-3: 3-value-2 3-3: 3-value-3
	 * 
	 * 4-4: 4-value-1 4-4: 4-value-2 4-4: 4-value-3
	 * 
	 */
	public Map<String, Set<String>> generateDefaultData() {

		Map<String, Set<String>> map = new HashMap<String, Set<String>>();

		Set<String> data = null;
		String key = null;
		String value = null;

		for (int i = 1; i < 5; i++) {
			// key
			key = i + "-" + i;
			System.out.println("key: " + key);
			// set value
			for (int x = 1; x < 4; x++) {
				value = i + "-value-" + x;
				data = new HashSet<String>();
				data.add(value);
			}
			// put into map
			map.put(key, data);
		}
		return map;
	}

}
