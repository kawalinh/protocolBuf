package tagcade.rtb.auction.controller;

import models.Person;
import play.data.DynamicForm;
import play.data.Form;
import play.mvc.Controller;
import play.mvc.Result;
import tagcade.rtb.auction.common.AdRequestValidator;
import tagcade.rtb.auction.model.AdRequest;
import tagcade.rtb.auction.service.AuctionService;
import tagcade.rtb.auction.service.AuctionService2;
import tagcade.rtb.auction.service.AuctionServiceInterface;

import com.google.gson.Gson;

public class TagCadeAuctionController extends Controller {

	static AuctionServiceInterface auctionServiceInterface = new AuctionService();

	public TagCadeAuctionController() {
		super();
	}

	public static Result createAdRequest(AdRequest adRequest) {
		return ok("A request is created");
	}

	public static Result createAdRequest() {
		String userId = "DTAG";
		System.out.println("userId: " + userId);
		AdRequest adRequest = new AdRequest(userId);
		AuctionService2 service = new AuctionService2();
		service.processAdRequest(adRequest);
		return ok("A request is created");
	}

	public static Result createPostAdRequest_pre() {
		DynamicForm requestData = Form.form().bindFromRequest();
		String data = requestData.get("data");
		if (data != null) {
			Gson gson = new Gson();
			try {
				Person person = gson.fromJson(data, Person.class);
				System.out.println("Person Name: " + person.getName());
				System.out.println("Person AGE: " + person.getAge());
				System.out.println("Person NUmber: " + person.getNumber());
			} catch (Exception e) {
				System.out.println("Error: " + e.getMessage());
			}
		}

		AdRequest adRequest = new AdRequest(data);
		auctionServiceInterface.processAdRequest(adRequest);
		return ok("jsonAdRequest: " + data);
	}

	public static Result createPostAdRequest() {
		DynamicForm requestData = Form.form().bindFromRequest();
		String data = requestData.get("data");
		if (data != null) {
			Gson gson = new Gson();
			try {
				AdRequest adRequest = gson.fromJson(data, AdRequest.class);
				AdRequestValidator requestValidator = new AdRequestValidator();
				boolean validRs = requestValidator.validate(adRequest);
				if (!validRs) {
					return ok("Invalid data");
				}
				AuctionService2 service = new AuctionService2();
				service.processAdRequest(adRequest);
			} catch (Exception e) {
				System.out.println("Error: " + e.getMessage());
			}
		}

		AdRequest adRequest = new AdRequest(data);
		auctionServiceInterface.processAdRequest(adRequest);
		return ok("jsonAdRequest: " + data);
	}

}
