package tagcade.rtb.auction.data.refs;
/**
 * 
 * @author LinhLT
 *
 */
public interface AdPosition {

    
    int UNKNOWN = 0;
    
   
    int ABOVE_THE_FOLD = 1;
    
   
    int DEPRECATED = 2;
    
   
    int BELOW_THE_FOLD = 3;
    
    
    int HEADER = 4;
    
   
    int FOOTER = 5;
    
    
    int SIDEBAR = 6;
    
    
    int FULLSCREEN = 7;
    
}
