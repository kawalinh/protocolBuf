package tagcade.rtb.auction.factory;

public class Factory {
	/**
	 * 
	 * @param input
	 * @return
	 */
	public String parserInputJsonIntoBidRequest(String input) {

		// TODO Auto-generated method stub

		return null;
	}
}
