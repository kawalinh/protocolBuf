package tagcade.rtb.auction.model;

public class AdDetail {

	public AdDetail() {
		
	}
}
