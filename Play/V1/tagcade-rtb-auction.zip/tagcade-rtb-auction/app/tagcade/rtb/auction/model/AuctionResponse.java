package tagcade.rtb.auction.model;

public class AuctionResponse {
	/**
	 * create model for auction response data
	 */
	private String userId;
	private String productId;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public AuctionResponse(String userId, String productId) {
		super();
		this.userId = userId;
		this.productId = productId;
	}

	public AuctionResponse() {
		super();
	}

}
