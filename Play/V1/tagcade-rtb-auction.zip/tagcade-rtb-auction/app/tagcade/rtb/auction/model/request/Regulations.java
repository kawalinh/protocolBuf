/**
 * 
 */
package tagcade.rtb.auction.model.request;

/**
 * @author pc
 * 
 */
public class Regulations {
	private int coppa;
	private String ext;

	/**
	 * 
	 * @param coppa
	 * @param ext
	 */
	public Regulations(int coppa, String ext) {
		super();
		this.coppa = coppa;
		this.ext = ext;
	}

	public Regulations() {
		super();
	}

	public int getCoppa() {
		return coppa;
	}

	public void setCoppa(int coppa) {
		this.coppa = coppa;
	}

	public String getExt() {
		return ext;
	}

	public void setExt(String ext) {
		this.ext = ext;
	}
}
