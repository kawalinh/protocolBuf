package tagcade.rtb.auction.service;

import java.util.List;

import tagcade.rtb.auction.builder.BidRequestBuilder;
import tagcade.rtb.auction.builder.BidRequestBuilderInterface;
import tagcade.rtb.auction.common.DSPGroupConfig;
import tagcade.rtb.auction.model.AdDetail;
import tagcade.rtb.auction.model.AdRequest;
import tagcade.rtb.auction.model.DSP;
import tagcade.rtb.auction.model.request.BidRequest;
import tagcade.rtb.auction.model.response.BidResponse;

public class AuctionService implements AuctionServiceInterface {

	public AuctionService() {
		super();
	}

	private BidRequestBuilderInterface bidRequestBuilder = new BidRequestBuilder();

	DSPGroupConfig config = new DSPGroupConfig();

	private DSPRequestor dspManager = new DSPRequestor(config);

	public AuctionService(BidRequestBuilder bidRequestBuilder,DSPRequestor dspManager) {
		this.bidRequestBuilder = bidRequestBuilder;
		this.dspManager = dspManager;
	}

	@Override
	public AuctionResponse processAdRequest(AdRequest adRequest)
			throws RuntimeException {
		
		// Step 1: create bid request from AdRequest.
		AdDetail adDetail = null; // GET ad detail from repository class
								  // require accessing database or mem cache

		BidRequest bidRequest = this.bidRequestBuilder.buildBidRequest(adRequest, adDetail);

		// Step 2: send bid request to DSPs and receive Auction response
		List<BidResponse> bidResponses = this.dspManager
				.sendBidRequest(bidRequest);

		// Step 2.1 --- filter invalid bid response

		// Step 2.2 ---

		// Step 3: define winner
		DSP winnder = this.getWinnder(bidResponses);

		// Step 4. send log job for statistics

		// Step 5. return auction response DTO
		return new AuctionResponse(winnder);
	}

	@Override
	public DSP getWinnder(List<BidResponse> responses) {
		// TODO Auto-generated method stub
		return null;
	}

}
