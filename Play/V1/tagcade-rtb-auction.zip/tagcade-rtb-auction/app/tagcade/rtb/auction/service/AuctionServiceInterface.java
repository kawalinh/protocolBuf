package tagcade.rtb.auction.service;

import java.util.List;

import tagcade.rtb.auction.model.AdRequest;
import tagcade.rtb.auction.model.DSP;
import tagcade.rtb.auction.model.response.BidResponse;

public interface AuctionServiceInterface {
	
	public AuctionResponse processAdRequest(AdRequest adRequest ) throws RuntimeException;
	
	public DSP getWinnder(List<BidResponse> responses);
			
}
