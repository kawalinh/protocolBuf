package tagcade.rtb.auction.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import tagcade.rtb.auction.common.DSPGroupConfig;
import tagcade.rtb.auction.model.request.BidRequest;
import tagcade.rtb.auction.model.response.BidResponse;

public class DSPRequestor implements DSPRequestorInterface {

	private DSPGroupConfig dspGroupConfig;

	public DSPRequestor(DSPGroupConfig dspGroupConfig) {
		this.dspGroupConfig = dspGroupConfig;
	}

	@Override
	public List<BidResponse> sendBidRequest(BidRequest bidRequest) {

		List<BidResponse> responses = new ArrayList<BidResponse>();
		ExecuteBidRequest executeBidRequest = new ExecuteBidRequest();
		BidResponse response;
		String key = "1-1";
		Set<String> listDSPs = dspGroupConfig.getConfig(key);
		Iterator<String> iterator = listDSPs.iterator();
		if (iterator.hasNext()) {
			String dsp = iterator.next();
			System.out.println("dsp Name: " + dsp);
			response = executeBidRequest.execute(bidRequest, dsp);
			responses.add(response);
		}
		return responses;
	}

}
