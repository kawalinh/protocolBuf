
<h2>Implementation Purpose</h2>

This project is focused on implementing SSP in OpenRTB system, that allows adServers can exchange data with DSPs by auction rules.

<h2>Project structure</h2>

<pre>
	- controller: execute the requests from ad servers
	- model.request: Object for request
	- model.response: Object for response
	- builder: build bidRequest
	- refs:reference logic of OpenRTB
	- service: execute logics
</pre>

<h2>References</h2>

https://github.com/openrtb/openrtb2x
http://www.iab.net/media/file/OpenRTBAPISpecificationVersion2_2.pdf
https://github.com/nginad/nginad
