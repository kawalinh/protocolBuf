package controllers;

import models.Person;

import org.springframework.beans.factory.annotation.Autowired;

import play.data.Form;
import play.mvc.Controller;
import play.mvc.Result;
import services.HelloService;
import services.TestService;
import views.html.index;


@org.springframework.stereotype.Controller
public class Application extends Controller {
	@Autowired
	private HelloService helloService;
	@Autowired
	private TestService testService;
	private static String age;
	private static Form<Person> personForm = Form.form(Person.class);

	public  Result index() {
		String test = testService.showMessage();
  		System.out.println(test);
  		
  		String message = helloService.hello();
  		System.out.println("message");
  		String add = " -- add this in the end";
  		return ok(index.render(message +" - - " + test + add));
	}

	public static Result gotoPersonForm() {
		return ok("Your new application is ready.");
	}

	public static Result createPerson() {
		
		Person person = personForm.bindFromRequest().get();
		age = person.getAge();
		return ok("PERSON age: "+age);
	}

}
