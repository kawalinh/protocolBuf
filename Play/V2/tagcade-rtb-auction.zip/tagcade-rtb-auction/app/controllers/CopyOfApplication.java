package controllers;

import java.util.HashMap;
import java.util.Map;

import models.Person;
import play.data.Form;
import play.mvc.Controller;
import play.mvc.Result;
import views.html.index;



public class CopyOfApplication extends Controller {

	private static String age;
	private static Form<Person> personForm = Form.form(Person.class);

	public static Result index() {
		return ok(index.render("Your new application is ready."));
	}

	public static Result gotoPersonForm() {
		
		Map<String,String> anyData = new HashMap<String,String>();
		anyData.put("name", "dtag");
		anyData.put("number", "1");
		Person person = personForm.bind(anyData).get();
		return ok("Your new application is ready.");
	}

	public static Result createPerson() {
		
		Person person = personForm.bindFromRequest().get();
		age = person.getAge();
		return ok("PERSON age: "+age);
	}

}
