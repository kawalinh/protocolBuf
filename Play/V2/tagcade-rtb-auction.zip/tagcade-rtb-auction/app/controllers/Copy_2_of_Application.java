package controllers;

import play.*;
import play.mvc.*;

import views.html.*;

import services.*;

import org.springframework.beans.factory.annotation.*;

@org.springframework.stereotype.Controller
public class Copy_2_of_Application extends Controller {

	@Autowired
	private HelloService helloService;
	@Autowired
	private TestService testService;
  
  	public Result index() {
  		
  		String test = testService.showMessage();
  		System.out.println(test);
  		
  		String message = helloService.hello();
  		System.out.println("message");
    	return ok(index.render(message +" - - " + test ));
  	}
  
}