package services;

public interface GreetingService {
	String greeting();
}
