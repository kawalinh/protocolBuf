package services;

@org.springframework.stereotype.Service
public class HelloService {

	public String hello() {
		return "Hello world!";
	}

}