package services;

public class RealGreetingService implements GreetingService{

	@Override
	public String greeting() {
		System.out.println("------------run the method here: greeting()-----------------------------");
		return "D" +
				"tag";
	}

}
