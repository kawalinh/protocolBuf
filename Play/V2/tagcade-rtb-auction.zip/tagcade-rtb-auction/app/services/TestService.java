package services;
@org.springframework.stereotype.Service
public class TestService {
	// test xem config o dau
// th 1: khong co constructor
// th 1: su dung constructor
	
	public String showMessage(){
		System.out.println("say something here");
		return "test config";
	}
}
