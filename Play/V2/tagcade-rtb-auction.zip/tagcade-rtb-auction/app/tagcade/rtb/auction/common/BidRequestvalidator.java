/**
 * 
 */
package tagcade.rtb.auction.common;

/**
 * @author pc
 *
 */
public class BidRequestvalidator {


}
