/**
 * 
 */
package tagcade.rtb.auction.common;

/**
 * @author pc
 *
 */
public class TagCadeConstant {
public static final String SUCCESS = "SUCCESS";
public static final String FAIL = "FAIL";
}
