package tagcade.rtb.auction.model;

public class AdRequest {
	
	private String userId;
	
	public AdRequest() {
		
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public AdRequest(String userId) {
		super();
		this.userId = userId;
	}

}
