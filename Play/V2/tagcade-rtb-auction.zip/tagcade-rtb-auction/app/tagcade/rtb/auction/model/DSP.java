package tagcade.rtb.auction.model;

public class DSP {

	public DSP() {
		
	}
}
