package tagcade.rtb.auction.model.request;

import tagcade.rtb.auction.data.refs.APIFrameworks;
import tagcade.rtb.auction.data.refs.AdPosition;
import tagcade.rtb.auction.data.refs.BannerAdTypes;
import tagcade.rtb.auction.data.refs.CreativeAttributes;
import tagcade.rtb.auction.data.refs.ExpandableDirection;

/**
 * The “banner" object must be included directly in the impression object if
 * the impression offered for auction is display or rich media, or it may be
 * optionally embedded in the video object to describe the companion banners
 * available for the linear or non-linear video ad. The banner object may
 * include a unique identifier; this can be useful if these IDs can be leveraged
 * in the VAST response to dictate placement of the companion creatives when
 * multiple companion ad opportunities of the same size are available on a page.
 * 
 * @author pc
 * 
 */
public class Banner {

	/**
	 * Width of the impression in pixels. Since some ad types are not restricted
	 * by size this field is not required, but it’s highly recommended that this
	 * information be included when possible. Recommended.
	 */
	private Integer w;

	/**
	 * Height of the impression in pixels. Since some ad types are not
	 * restricted by size this field is not required, but it’s highly
	 * recommended that this information be included when possible. Recommended.
	 */
	private Integer h;
	/**
	 * Maximum width of the impression in pixels. If included, it indicates that
	 * a range of sizes is allowed with this maximum width and "w" is taken as
	 * recommended. If not included, then "w" should be considered an exact
	 * requirement
	 */
	private int wmax;
	/**
	 * Maximum height of the impression in pixels. If included, it indicates
	 * that a range of sizes is allowed with this maximum height and "h" is
	 * taken as recommended. If not included, then "h" should be considered an
	 * exact requirement.
	 */
	private int hmax;
	/**
	 * Minimum width of the impression in pixels. If included, it indicates that
	 * a range of sizes is allowed with this minimum width and "w" is taken as
	 * recommended. If not included, then "w" should be considered an exact
	 * requirement.
	 */
	private int wmin;
	/**
	 * Minimum height of the impression in pixels. If included, it indicates
	 * that a range of sizes is allowed with this minimum height and "h" is
	 * taken as recommended. If not included, then "h" should be considered an
	 * exact requirement.
	 */
	private int hmin;

	/**
	 * Unique identifier for this banner object. Useful for tracking multiple
	 * banner objects (e.g., in companion banner array). Usually starts with 1,
	 * increasing with each object. Combination of impression id banner object
	 * should be unique.
	 */
	private String id;

	/**
	 * Ad Position. Use Specification Table 6.5 or {@link AdPosition}
	 */
	private Integer pos = null;

	/**
	 * Blocked creative types. See Specification Table 6.2 Banner Ad Types or
	 * {@link BannerAdTypes}. If blank, assume all types are allowed.
	 */
	private Integer[] btype = null;

	/**
	 * Blocked creative attributes. See Specification Table 6.3 Creative
	 * Attributes or {@link CreativeAttributes}. If blank assume all types are
	 * allowed
	 */
	private Integer[] battr = null;

	/**
	 * Whitelist of content MIME types supported. Popular MIME types include,
	 * but are not limited to “image/jpg�?, “image/gif�? and
	 * “application/x-shockwave-flash�?.
	 */
	private String[] mimes = null;

	/**
	 * Specify if the banner is delivered in the top frame or in an iframe. “0�?
	 * means it is not in the top frame, and “1�? means that it is.
	 */
	private int topframe = 0;

	/**
	 * Specify properties for an expandable ad. See Specification Table 6.11
	 * Expandable Direction or {@link ExpandableDirection} for possible values.
	 */
	private Integer[] expdir = null;

	/**
	 * List of supported API frameworks for this banner. (See Specification
	 * Table 6.4 API Frameworks or {@link APIFrameworks}). If an API is not
	 * explicitly listed it is assumed not to be supported.
	 */
	private Integer[] api = null;

	/**
	 * This object is a placeholder that may contain custom JSON agreed to by
	 * the parties in an OpenRTB transaction to support flexibility beyond the
	 * standard defined in this specification.
	 */
	private String ext = null;

	/**
	 * @return the w
	 */
	public Integer getW() {
		return w;
	}

	/**
	 * @param w
	 *            the w to set
	 */
	public void setW(Integer w) {
		this.w = w;
	}

	/**
	 * @return the h
	 */
	public Integer getH() {
		return h;
	}

	/**
	 * @param h
	 *            the h to set
	 */
	public void setH(Integer h) {
		this.h = h;
	}

	/**
	 * @return the wmax
	 */
	public int getWmax() {
		return wmax;
	}

	/**
	 * @param wmax
	 *            the wmax to set
	 */
	public void setWmax(int wmax) {
		this.wmax = wmax;
	}

	/**
	 * @return the hmax
	 */
	public int getHmax() {
		return hmax;
	}

	/**
	 * @param hmax
	 *            the hmax to set
	 */
	public void setHmax(int hmax) {
		this.hmax = hmax;
	}

	/**
	 * @return the wmin
	 */
	public int getWmin() {
		return wmin;
	}

	/**
	 * @param wmin
	 *            the wmin to set
	 */
	public void setWmin(int wmin) {
		this.wmin = wmin;
	}

	/**
	 * @return the hmin
	 */
	public int getHmin() {
		return hmin;
	}

	/**
	 * @param hmin
	 *            the hmin to set
	 */
	public void setHmin(int hmin) {
		this.hmin = hmin;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the pos
	 */
	public Integer getPos() {
		return pos;
	}

	/**
	 * @param pos
	 *            the pos to set
	 */
	public void setPos(Integer pos) {
		this.pos = pos;
	}

	/**
	 * @return the btype
	 */
	public Integer[] getBtype() {
		return btype;
	}

	/**
	 * @param btype
	 *            the btype to set
	 */
	public void setBtype(Integer[] btype) {
		this.btype = btype;
	}

	/**
	 * @return the battr
	 */
	public Integer[] getBattr() {
		return battr;
	}

	/**
	 * @param battr
	 *            the battr to set
	 */
	public void setBattr(Integer[] battr) {
		this.battr = battr;
	}

	/**
	 * @return the mimes
	 */
	public String[] getMimes() {
		return mimes;
	}

	/**
	 * @param mimes
	 *            the mimes to set
	 */
	public void setMimes(String[] mimes) {
		this.mimes = mimes;
	}

	/**
	 * @return the topframe
	 */
	public int getTopframe() {
		return topframe;
	}

	/**
	 * @param topframe
	 *            the topframe to set
	 */
	public void setTopframe(int topframe) {
		this.topframe = topframe;
	}

	/**
	 * @return the expdir
	 */
	public Integer[] getExpdir() {
		return expdir;
	}

	/**
	 * @param expdir
	 *            the expdir to set
	 */
	public void setExpdir(Integer[] expdir) {
		this.expdir = expdir;
	}

	/**
	 * @return the api
	 */
	public Integer[] getApi() {
		return api;
	}

	/**
	 * @param api
	 *            the api to set
	 */
	public void setApi(Integer[] api) {
		this.api = api;
	}

	/**
	 * @return the ext
	 */
	public String getExt() {
		return ext;
	}

	/**
	 * @param ext
	 *            the ext to set
	 */
	public void setExt(String ext) {
		this.ext = ext;
	}

	/**
	 * @param w
	 * @param h
	 * @param wmax
	 * @param hmax
	 * @param wmin
	 * @param hmin
	 * @param id
	 * @param pos
	 * @param btype
	 * @param battr
	 * @param mimes
	 * @param topframe
	 * @param expdir
	 * @param api
	 * @param ext
	 */
	public Banner(Integer w, Integer h, int wmax, int hmax, int wmin, int hmin,
			String id, Integer pos, Integer[] btype, Integer[] battr,
			String[] mimes, int topframe, Integer[] expdir, Integer[] api,
			String ext) {
		super();
		this.w = w;
		this.h = h;
		this.wmax = wmax;
		this.hmax = hmax;
		this.wmin = wmin;
		this.hmin = hmin;
		this.id = id;
		this.pos = pos;
		this.btype = btype;
		this.battr = battr;
		this.mimes = mimes;
		this.topframe = topframe;
		this.expdir = expdir;
		this.api = api;
		this.ext = ext;
	}

	/**
	 * 
	 */
	public Banner() {
		super();
	}

}
