/**
 * 
 */
package tagcade.rtb.auction.model.request;

/**
 * @author pc
 * 
 */
public class Deal {
	private String id;
	private float bidfoor = 0;
	private String bidfloorcur = "USD";
	private String[] wseat;
	private String[] wadomain;
	private int at;
	private String ext;

	/**
	 * @param id
	 * @param bidfoor
	 * @param bidfloorcur
	 * @param wseat
	 * @param wadomain
	 * @param at
	 * @param ext
	 */
	public Deal(String id, float bidfoor, String bidfloorcur, String[] wseat,
			String[] wadomain, int at, String ext) {
		super();
		this.id = id;
		this.bidfoor = bidfoor;
		this.bidfloorcur = bidfloorcur;
		this.wseat = wseat;
		this.wadomain = wadomain;
		this.at = at;
		this.ext = ext;
	}

	public Deal() {
		super();
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public float getBidfoor() {
		return bidfoor;
	}

	public void setBidfoor(float bidfoor) {
		this.bidfoor = bidfoor;
	}

	public String getBidfloorcur() {
		return bidfloorcur;
	}

	public void setBidfloorcur(String bidfloorcur) {
		this.bidfloorcur = bidfloorcur;
	}

	public String[] getWseat() {
		return wseat;
	}

	public void setWseat(String[] wseat) {
		this.wseat = wseat;
	}

	public String[] getWadomain() {
		return wadomain;
	}

	public void setWadomain(String[] wadomain) {
		this.wadomain = wadomain;
	}

	public int getAt() {
		return at;
	}

	public void setAt(int at) {
		this.at = at;
	}

	public String getExt() {
		return ext;
	}

	public void setExt(String ext) {
		this.ext = ext;
	}

}
