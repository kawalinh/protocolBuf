/**
 * 
 */
package tagcade.rtb.auction.model.request;

/**
 * @author pc
 * 
 */
public class PMP {
	private int private_auction;
	private Deal[] deals;
	private String ext;

	/**
	 * @param private_auction
	 * @param deals
	 * @param ext
	 */
	public PMP(int private_auction, Deal[] deals, String ext) {
		super();
		this.private_auction = private_auction;
		this.deals = deals;
		this.ext = ext;
	}

	public PMP() {
		super();
	}

	public int getPrivate_auction() {
		return private_auction;
	}

	public void setPrivate_auction(int private_auction) {
		this.private_auction = private_auction;
	}

	public Deal[] getDeals() {
		return deals;
	}

	public void setDeals(Deal[] deals) {
		this.deals = deals;
	}

	public String getExt() {
		return ext;
	}

	public void setExt(String ext) {
		this.ext = ext;
	}

}
