package tagcade.rtb.auction.service;

import tagcade.rtb.auction.model.DSP;

public class AuctionResponse {
	
	private DSP winner;
	
	public AuctionResponse(DSP winner) {
		this.winner = winner;
	}

	public DSP getWinnder() {
		return this.winner;
	}
}
