package tagcade.rtb.auction.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import tagcade.rtb.auction.builder.BidRequestBuilder;
import tagcade.rtb.auction.builder.BidRequestBuilderInterface;
import tagcade.rtb.auction.common.DSPGroupConfig;
import tagcade.rtb.auction.model.AdDetail;
import tagcade.rtb.auction.model.AdRequest;
import tagcade.rtb.auction.model.DSP;
import tagcade.rtb.auction.model.request.BidRequest;
import tagcade.rtb.auction.model.response.BidResponse;

public class AuctionService2 implements AuctionServiceInterface {
	private BidRequestBuilderInterface bidRequestBuilder = new BidRequestBuilder();

	@Override
	public AuctionResponse processAdRequest(AdRequest adRequest)
			throws RuntimeException {

		List<BidResponse> responses = new ArrayList<BidResponse>();
		DSPGroupConfig config = new DSPGroupConfig();
		String key = "1-1";
		Set<String> dspConfig = config.getConfig(key);

		DSPRequestor2 dspManager = new DSPRequestor2(dspConfig);

		AdDetail adDetail = null;

		BidRequest bidRequest = bidRequestBuilder.buildBidRequest(adRequest,
				adDetail);
		responses = dspManager.sendBidRequest(bidRequest);
		DSP winner = getWinnder(responses);

		//
		// --> win notification
		//

		return new AuctionResponse(winner);
	}

	@Override
	public DSP getWinnder(List<BidResponse> responses) {
		return null;
	}

}
