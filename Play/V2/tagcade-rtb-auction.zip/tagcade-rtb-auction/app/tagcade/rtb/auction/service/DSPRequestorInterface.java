package tagcade.rtb.auction.service;

import java.util.List;

import tagcade.rtb.auction.model.request.BidRequest;
import tagcade.rtb.auction.model.response.BidResponse;

public interface DSPRequestorInterface {

	public List<BidResponse> sendBidRequest(BidRequest bidRequest);
}
