package tagcade.rtb.auction.service;

import tagcade.rtb.auction.model.request.BidRequest;
import tagcade.rtb.auction.model.response.BidResponse;

public class ExecuteBidRequest {
public BidResponse execute(BidRequest bidRequest, String dsp){
	BidResponse response = new BidResponse();
	return response;
}
}
